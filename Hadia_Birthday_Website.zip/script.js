function playMusic() {
  var music = document.getElementById('birthdaySong');
  music.play();
}
